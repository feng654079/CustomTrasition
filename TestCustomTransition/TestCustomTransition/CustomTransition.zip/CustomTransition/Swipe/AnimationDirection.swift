//
//  AnimationDirection.swift
//  TestCustomTransition
//
//  Created by apple on 2021/1/7.
//

import Foundation

public enum AnimationDirection {
    case toLeft
    case toRight
    case toBottom
    case toTop
}
